﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using HadlowDVDLibraryCL.HadlowLibraryServiceProxy;

namespace HadlowDVDLibraryCL
{
    public partial class Form1 : Form
    {


        public Form1()
        {
            InitializeComponent();
            tabControl1.Selected += new TabControlEventHandler(tabControl1_Selected);
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            
            refreshTable();

            cboTypeOfMember.Items.Add("Adult");
            cboTypeOfMember.Items.Add("Child");
            cboTypeOfMember.Items.Add("Senior");
            cboTypeOfMember.SelectedItem = "Adult";
        }



//Quit Button
        private void btnQuit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
//Tab Control
        private void tabControl1_Selected(object sender, TabControlEventArgs e)
        {
            lblProgress.Text = "Progress...";
            refreshTable();
        }
//Refresh Table
        public void refreshTable()
        {
            
            
            switch (tabControl1.SelectedIndex)
            {
                case 0:
                    {
                        try
                        {
                            HadlowLibraryServiceProxy.HadlowLibraryServiceClient client = new HadlowLibraryServiceProxy.HadlowLibraryServiceClient();


                            dgvLibraryTable.DataSource = client.getAllDVDs();

                        }
                        catch (Exception ex)
                        {

                            MessageBox.Show(ex.Message);
                        }
                        
                        
                        loadDVDID();
                    }
                    break;
                case 1: case 2:
                    {
                        try
                        {
                            HadlowLibraryServiceProxy.HadlowLibraryServiceClient client = new HadlowLibraryServiceProxy.HadlowLibraryServiceClient();

                            dgvLibraryTable.DataSource = client.getAllLoans();
                            loadMemberID();

                        }
                        catch (Exception ex)
                        {

                            MessageBox.Show(ex.Message);
                        }
                        txtIssue.Text = (DateTime.Now.ToString("d"));
                        txtDue.Text = (DateTime.Now.AddDays(7).ToString("d"));
                        loadDVDID();
                        loadLoanID();
                    }
                    break;
                case 3:
                    {
                        try
                        {
                            HadlowLibraryServiceProxy.HadlowLibraryServiceClient client = new HadlowLibraryServiceProxy.HadlowLibraryServiceClient();

                            dgvLibraryTable.DataSource = client.getAllMembers();
                            loadMemberID();
                        }
                        catch (Exception ex)
                        {

                            MessageBox.Show(ex.Message);
                        }
                    }
                    break;

            }
        }
//Register Member Button
        private void btnRegister_Click(object sender, EventArgs e)
        {
                try
                {
                    String TypeOfMemberStr = cboTypeOfMember.SelectedItem.ToString();
                    HadlowLibraryServiceProxy.HadlowLibraryServiceClient client = new HadlowLibraryServiceProxy.HadlowLibraryServiceClient();
                    client.registerMember(txtTitle.Text, txtFirstName.Text, txtLastName.Text, txtAddress.Text, txtCounty.Text, txtPostCode.Text, txtTelephone.Text, TypeOfMemberStr); 
                    lblProgress.Text = "Member Added...";
                    refreshTable();
                    loadMemberID();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
        }

        private void btnRemoveMember_Click(object sender, EventArgs e)
        {
           
            String cboSelectedItem = cboMemberID.Text;
            HadlowLibraryServiceProxy.HadlowLibraryServiceClient client = new HadlowLibraryServiceProxy.HadlowLibraryServiceClient();
            client.deleteMember(cboSelectedItem);
            loadMemberID();
            refreshTable();
            lblProgress.Text = "Member Removed...";
        }

        private void btnUpdateMember_Click(object sender, EventArgs e)
        {
            String cboSelectedItem = cboMemberID.Text;
            String TypeOfMemberStr = cboTypeOfMember.Text;
            HadlowLibraryServiceProxy.HadlowLibraryServiceClient client = new HadlowLibraryServiceProxy.HadlowLibraryServiceClient();
            client.updateMember(cboSelectedItem, txtTitle.Text, txtFirstName.Text, txtLastName.Text, txtAddress.Text, txtCounty.Text, txtPostCode.Text, txtTelephone.Text, TypeOfMemberStr);
            loadMemberID();
            refreshTable();
            lblProgress.Text = "Member Updated...";
        }

        private void btnCheckFilm_Click(object sender, EventArgs e)
        {
            try
            {
                HadlowLibraryServiceProxy.HadlowLibraryServiceClient client = new HadlowLibraryServiceProxy.HadlowLibraryServiceClient();
                string checkStr = cboCheckDVDID.SelectedValue.ToString();
                dgvLibraryTable.DataSource = client.checkDVD(checkStr);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void btnLoanCheck_Click(object sender, EventArgs e)
        {

            try
            {
                HadlowLibraryServiceProxy.HadlowLibraryServiceClient client = new HadlowLibraryServiceProxy.HadlowLibraryServiceClient();
                string checkStr = cboLoanCheckMemberID.Text;
                dgvLibraryTable.DataSource = client.checkLoan(checkStr);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void btnReturnCheck_Click(object sender, EventArgs e)
        {
            try
            {
                HadlowLibraryServiceProxy.HadlowLibraryServiceClient client = new HadlowLibraryServiceProxy.HadlowLibraryServiceClient();
                string checkStr = cboReturnCheckMemberID.Text;               
                dgvLibraryTable.DataSource = client.checkLoan(checkStr);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        //public void fillFilmTitle(string cS) {
        //    OleDbConnection myConnection = DBConnectivity.GetConnection();
        //    DataTable dt = new DataTable();
        //    String myQuery = "SELECT DVDTitle FROM DVD WHERE DVDID=" + cS + "";
        //}

        private void btnLoan_Click(object sender, EventArgs e)
        {
            try
            {
                HadlowLibraryServiceProxy.HadlowLibraryServiceClient client = new HadlowLibraryServiceProxy.HadlowLibraryServiceClient();

                String DVDIDStr = cboLoanDVDID.Text;
                String memberIDStr = cboLoanMemberID.Text;
                String issueStr = (DateTime.Now.ToString("d"));
                String dueStr = (DateTime.Now.AddDays(7).ToString("d"));

                client.newLoan(DVDIDStr, memberIDStr, issueStr, dueStr);

                lblProgress.Text = "Loan Added...";
                stock();
                refreshTable();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            try
            {
                HadlowLibraryServiceProxy.HadlowLibraryServiceClient client = new HadlowLibraryServiceProxy.HadlowLibraryServiceClient();
                String loanIDStr = cboReturnLoanID.Text;
                client.returnLoan(loanIDStr);
                
                stock();
                
                
                lblProgress.Text = "Loan Removed...";
                refreshTable();
                loadLoanID();
                loadMemberID();

            }
            catch (Exception ex)
            {
              MessageBox.Show(ex.ToString());
            }
        }

       
        private void btnCheckReset_Click(object sender, EventArgs e)
        {
            refreshTable();
        }

        private void btnLoanReset_Click(object sender, EventArgs e)
        {
            refreshTable();
        }

        private void btnReturnReset_Click(object sender, EventArgs e)
        {
            refreshTable();
        }

       

        private void cboCheckDVDID_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                HadlowLibraryServiceProxy.HadlowLibraryServiceClient client = new HadlowLibraryServiceProxy.HadlowLibraryServiceClient();

                String cboSelectedItem = cboCheckDVDID.Text;

                txtFilmTitle.Text = client.getFilmTitle(cboSelectedItem);


            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
//Updating text fields.
        private void cboLoanDVDID_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            try
            {
                HadlowLibraryServiceProxy.HadlowLibraryServiceClient client = new HadlowLibraryServiceProxy.HadlowLibraryServiceClient();

                String cboSelectedItem = cboLoanDVDID.Text;

                txtLoanFilmTitle.Text = client.getFilmTitle(cboSelectedItem);

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void cboLoanMemberID_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                HadlowLibraryServiceProxy.HadlowLibraryServiceClient client = new HadlowLibraryServiceProxy.HadlowLibraryServiceClient();

                String cboSelectedItem = cboLoanMemberID.Text;

                txtLoanName.Text = client.getMemberName(cboSelectedItem);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void cboLoanCheckMemberID_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                HadlowLibraryServiceProxy.HadlowLibraryServiceClient client = new HadlowLibraryServiceProxy.HadlowLibraryServiceClient();

                String cboSelectedItem = cboLoanCheckMemberID.Text;

                txtLoanCheckMember.Text = client.getMemberName(cboSelectedItem);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void cboReturnCheckMemberID_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                HadlowLibraryServiceProxy.HadlowLibraryServiceClient client = new HadlowLibraryServiceProxy.HadlowLibraryServiceClient();

                String cboSelectedItem = cboReturnCheckMemberID.Text;

                txtReturnMemberID.Text = client.getMemberName(cboSelectedItem);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
//Aquire information to edit the Stock field in the database
        public void stock(){

            if (tabControl1.SelectedIndex == 1){
                try
                {
                    String DVDminus = cboLoanDVDID.Text;
                    HadlowLibraryServiceProxy.HadlowLibraryServiceClient client = new HadlowLibraryServiceProxy.HadlowLibraryServiceClient();
                    client.stockSorter(DVDminus, true);
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }
            }
            if (tabControl1.SelectedIndex == 2) {
                String DVDadd = getDVDID();
                HadlowLibraryServiceProxy.HadlowLibraryServiceClient client = new HadlowLibraryServiceProxy.HadlowLibraryServiceClient();
                client.stockSorter(DVDadd, false);
            }

            refreshTable();
        }

        public String getDVDID() {
            String loanID = cboReturnLoanID.Text;
            try
            {
                HadlowLibraryServiceProxy.HadlowLibraryServiceClient client = new HadlowLibraryServiceProxy.HadlowLibraryServiceClient();
                String dvdId = client.getDVDID(loanID);
                return dvdId;
            }
            catch (Exception ex) {
                MessageBox.Show(ex.ToString());
                return null;
            }

            
        }
//Load Data into Combo Boxes
        public void loadMemberID()
        {
            try
            {
                HadlowLibraryServiceProxy.HadlowLibraryServiceClient client = new HadlowLibraryServiceProxy.HadlowLibraryServiceClient();

                List<HadlowLibraryServiceProxy.Member> member = new List<HadlowLibraryServiceProxy.Member>(client.getAllMembers());
                switch (tabControl1.SelectedIndex) {
                    case 1:
                        {


                            cboLoanMemberID.ValueMember = "MembershipID";
                            cboLoanMemberID.DisplayMember = "MemberID";
                            cboLoanMemberID.DataSource = member;

                            cboLoanCheckMemberID.ValueMember = "MembershipID";
                            cboLoanCheckMemberID.DisplayMember = "MemberID";
                            cboLoanCheckMemberID.DataSource = member;
                        }
                        break;
                    case 2:
                        { 
                            cboReturnCheckMemberID.ValueMember = "MembershipID";
                            cboReturnCheckMemberID.DisplayMember = "MemberID";
                            cboReturnCheckMemberID.DataSource = member;
                        }
                        break;
                    case 3:
                        {
                            cboMemberID.ValueMember = "MembershipID";
                            cboMemberID.DisplayMember = "MemberID";
                            cboMemberID.DataSource = member;
                        }
                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            
        }

        public void loadDVDID()
        {
            switch (tabControl1.SelectedIndex)
            {
                case 0:
                    {
                        try
                        {
                            HadlowLibraryServiceProxy.HadlowLibraryServiceClient client = new HadlowLibraryServiceProxy.HadlowLibraryServiceClient();

                            List<DVD> dvdList = new List<DVD>(client.getDVDIds(true));
                            cboCheckDVDID.ValueMember = "DVDID";
                            cboCheckDVDID.DisplayMember = "DVDID";
                            cboCheckDVDID.DataSource = dvdList;
                            
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }
                    }
                    break;
                case 1:
                    {
                        try
                        {
                            HadlowLibraryServiceProxy.HadlowLibraryServiceClient client = new HadlowLibraryServiceProxy.HadlowLibraryServiceClient();

                            List<DVD> DVDList = new List<DVD>(client.getDVDIds(false));
                            cboLoanDVDID.ValueMember = "DVDID";
                            cboLoanDVDID.DisplayMember = "DVDID";
                            cboLoanDVDID.DataSource = DVDList;
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }
                        break;
                    }
                }
            }

        public void loadLoanID()
        {
            try
            {
                HadlowLibraryServiceProxy.HadlowLibraryServiceClient client = new HadlowLibraryServiceProxy.HadlowLibraryServiceClient();
                BindingSource bs = new BindingSource();
                bs.DataSource = client.getLoanIds();

                List<HadlowLibraryServiceProxy.Loan> loanList = new List<HadlowLibraryServiceProxy.Loan>(client.getAllLoans());

                cboReturnLoanID.ValueMember = "LoanID";
                cboReturnLoanID.DisplayMember = "LoanID";
                cboReturnLoanID.DataSource = loanList;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnLoanReport_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 1;
        }

        private void btnAvailable_Click(object sender, EventArgs e)
        {
            try
            {
                HadlowLibraryServiceProxy.HadlowLibraryServiceClient client = new HadlowLibraryServiceProxy.HadlowLibraryServiceClient();


                dgvLibraryTable.DataSource = client.getInStockDVDs();

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }


            loadDVDID();
        }

    }

}
