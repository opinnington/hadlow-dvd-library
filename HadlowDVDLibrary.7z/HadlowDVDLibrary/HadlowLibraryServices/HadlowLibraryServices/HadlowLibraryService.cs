﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;

namespace HadlowLibraryServices
{
    public class HadlowLibraryService : IHadlowLibraryService
    {
        String connStr = @"Provider=Microsoft.ACE.OLEDB.12.0; Data Source=..\..\..\HadlowDVDLibraryDB.accdb";
        String myCommand = null;
        OleDbConnection myConnection;

        public List<DVD> getAllDVDs()
        {
            List<DVD> AllDVDs = new List<DVD>();

            try
            {

                myConnection = new OleDbConnection(connStr);
                myCommand = "SELECT * FROM DVD ORDER BY DVDID ASC";


                OleDbCommand currentCommand = new OleDbCommand(myCommand, myConnection);

                myConnection.Open();
                OleDbDataReader myReader = currentCommand.ExecuteReader();

                while (myReader.Read())
                {
                    DVD MyDVD = new DVD();
                    MyDVD.DVDID = myReader["DVDID"].ToString();
                    MyDVD.DVDTitle = myReader["DVDTitle"].ToString();
                    MyDVD.Stock = myReader["Stock"].ToString();
                    MyDVD.Director = myReader["Director"].ToString();
                    MyDVD.Genre = myReader["Genre"].ToString();
                    MyDVD.MainActor = myReader["MainActor"].ToString();
                    AllDVDs.Add(MyDVD);
                }
                foreach (DVD item in AllDVDs)
                {
                    Console.Write(item.DVDID + " " + item.DVDTitle + "  " + item.Stock + "  " + item.Director + " " + item.Genre + " " + item.MainActor + "\n");
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return AllDVDs;
        }

        public List<Loan> getAllLoans() {

            List<Loan> AllLoans = new List<Loan>();
            try
            {
                myConnection = new OleDbConnection(connStr);
                myCommand = "SELECT * FROM Loan ORDER BY LoanID ASC";


                OleDbCommand currentCommand = new OleDbCommand(myCommand, myConnection);

                myConnection.Open();
                OleDbDataReader myReader = currentCommand.ExecuteReader();

                while (myReader.Read())
                {
                    Loan MyLoan = new Loan();
                    MyLoan.LoanId = myReader["LoanID"].ToString();
                    MyLoan.DVDID = myReader["DVDID"].ToString();
                    MyLoan.MemberID = myReader["MemberID"].ToString();
                    MyLoan.StartDate = myReader["StartDate"].ToString();
                    MyLoan.ReturnDate = myReader["ReturnDate"].ToString();
                    String dueStr = myReader["ReturnDate"].ToString();
                    DateTime due = DateTime.Parse(dueStr);
                    int fine;
                    if (DateTime.Now > due)
                    {

                        TimeSpan timespan = DateTime.Now.Subtract(due);
                        Console.WriteLine("There are {0} number of days between {1} and {2}", timespan.TotalDays, DateTime.Now.ToShortDateString(), due.ToShortDateString());

                        if (timespan.TotalDays > 1)
                        {
                            fine = 5;
                            MyLoan.Fine = fine.ToString();
                        } 
                        if (timespan.TotalDays > 5)
                        {
                            fine = 50;
                            MyLoan.Fine = fine.ToString();
                        }
                        if (timespan.TotalDays > 10)
                        {
                            fine = 75;
                            MyLoan.Fine = fine.ToString();
                        }
                        if (timespan.TotalDays > 30)
                        {
                            fine = 200;
                            MyLoan.Fine = fine.ToString();
                        }
                        
                    }
                    else {
                        fine = 0;
                        MyLoan.Fine = fine.ToString();
                    }
                    
                    AllLoans.Add(MyLoan);
                }
                foreach (Loan item in AllLoans)
                {
                    Console.Write(item.LoanId + " " + item.DVDID + "  " + item.MemberID + "  " + item.StartDate + " " + item.ReturnDate + "\n");
                }
            }
            catch (Exception ex) {
                Console.WriteLine(ex.ToString());
                
            }
            return AllLoans;
        }

        public List<Member> getAllMembers()
        {
            List<Member> AllMembers = new List<Member>();
            try
            {
                myConnection = new OleDbConnection(connStr);
                myCommand = "SELECT * FROM Member ORDER BY MembershipID ASC";


                OleDbCommand currentCommand = new OleDbCommand(myCommand, myConnection);

                myConnection.Open();
                OleDbDataReader myReader = currentCommand.ExecuteReader();

                while (myReader.Read())
                {
                    Member MyMember = new Member();
                    MyMember.MemberId = myReader["MembershipID"].ToString();
                    MyMember.Title = myReader["Title"].ToString();
                    MyMember.FirstName = myReader["FirstName"].ToString();
                    MyMember.SurName = myReader["Surname"].ToString();
                    MyMember.Address = myReader["Address"].ToString();
                    MyMember.County = myReader["County"].ToString();
                    MyMember.PostCode = myReader["PostCode"].ToString();
                    MyMember.TelePhone = myReader["TelePhone"].ToString();
                    MyMember.TypeOfMember = myReader["TypeOfMember"].ToString();
                    AllMembers.Add(MyMember);
                    
                }
                foreach (Member item in AllMembers)
                {
                    Console.Write(item.MemberId + " " + item.Title + "  " + item.FirstName + "  " + item.SurName + " " + item.Address + " " + item.County + " " + item.PostCode + " " + item.TelePhone + " " + item.TypeOfMember + "\n");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());

            }
            return AllMembers;
        }

        public List<DVD> getDVDIds(bool i)
        {
            if (i == true) {
                myCommand = "SELECT DVDID FROM DVD ORDER BY DVDID ASC";
            }
            if (i == false) {
                myCommand = "SELECT * FROM DVD WHERE Stock > 0 ORDER BY DVDID ASC";
            }
            List<DVD> allIds = new List<DVD>();
            try
            {
                myConnection = new OleDbConnection(connStr);
                
                OleDbCommand currentCommand = new OleDbCommand(myCommand, myConnection);

                myConnection.Open();

                OleDbDataReader myReader = currentCommand.ExecuteReader();
                while(myReader.Read())
                {
                    DVD MyDVD = new DVD();
                    MyDVD.DVDID = myReader["DVDID"].ToString();

                    allIds.Add(MyDVD);
                }
                foreach (DVD item in allIds)
                {
                    Console.Write(item.DVDID + " " + "\n");
                }
                myConnection.Close();
                return allIds;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                myConnection.Close();
                return null;
            }
        }

        public List<DVD> getInStockDVDs() {
            List<DVD> AllDVDs = new List<DVD>();

            try
            {

                myConnection = new OleDbConnection(connStr);
                myCommand = "SELECT * FROM DVD WHERE Stock > 0 ORDER BY DVDID ASC";


                OleDbCommand currentCommand = new OleDbCommand(myCommand, myConnection);

                myConnection.Open();
                OleDbDataReader myReader = currentCommand.ExecuteReader();

                while (myReader.Read())
                {
                    DVD MyDVD = new DVD();
                    MyDVD.DVDID = myReader["DVDID"].ToString();
                    MyDVD.DVDTitle = myReader["DVDTitle"].ToString();
                    MyDVD.Stock = myReader["Stock"].ToString();
                    MyDVD.Director = myReader["Director"].ToString();
                    MyDVD.Genre = myReader["Genre"].ToString();
                    MyDVD.MainActor = myReader["MainActor"].ToString();
                    AllDVDs.Add(MyDVD);
                }
                foreach (DVD item in AllDVDs)
                {
                    Console.Write(item.DVDID + " " + item.DVDTitle + "  " + item.Stock + "  " + item.Director + " " + item.Genre + " " + item.MainActor + "\n");
                }
                return AllDVDs;
            }
            catch (Exception ex) {
                Console.WriteLine(ex.ToString());
            }
            return null;
        }
        public List<Loan> getLoanIds() {


            List<Loan> allIds = new List<Loan>();
            try
            {
                myConnection = new OleDbConnection(connStr);
                myCommand = "SELECT LoanID FROM Loan ORDER BY LoanID ASC";
                OleDbCommand currentCommand = new OleDbCommand(myCommand, myConnection);

                myConnection.Open();

                OleDbDataReader myReader = currentCommand.ExecuteReader();
                while (myReader.Read())
                {
                    Loan MyLoan = new Loan();
                    MyLoan.DVDID = myReader["LoanID"].ToString();

                    allIds.Add(MyLoan);
                }
                foreach (Loan item in allIds)
                {
                    Console.Write(item.LoanId + " " + "\n");
                }
                myConnection.Close();
                return allIds;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                myConnection.Close();
                return null;
            }
        }

        public List<Member> getMemberIds() {
            List<Member> allIds = new List<Member>();
            try
            {
                myConnection = new OleDbConnection(connStr);
                myCommand = "SELECT MembershipID FROM Member ORDER BY MembershipID ASC";
                OleDbCommand currentCommand = new OleDbCommand(myCommand, myConnection);

                myConnection.Open();

                OleDbDataReader myReader = currentCommand.ExecuteReader();
                while (myReader.Read())
                {
                    Member MyMember = new Member();
                    MyMember.MemberId = myReader["MembershipID"].ToString();

                    allIds.Add(MyMember);
                }
                foreach (Member item in allIds)
                {
                    Console.Write(item.MemberId + " " + "\n");
                }
                myConnection.Close();
                return allIds;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                myConnection.Close();
                return null;
            }
            
        }
        public String getFilmTitle(String i) {

            myConnection = new OleDbConnection(connStr);
            String myCommand = "SELECT DVDTitle FROM DVD WHERE DVDID=" + i + "";
            OleDbCommand currentCommand = new OleDbCommand(myCommand, myConnection);
            try
            {
                myConnection.Open();
                OleDbDataReader reader = currentCommand.ExecuteReader();

                while (reader.Read())
                {
                    String filmTitle = reader["DVDTitle"].ToString();
                    return filmTitle;
                }
            reader.Close();
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                myConnection.Close();
            }


            return null;
        }

        public String getMemberName(String i)
        {

            myConnection = new OleDbConnection(connStr);
            String myCommand = "SELECT FirstName FROM Member WHERE MembershipID=" + i + "";
            OleDbCommand currentCommand = new OleDbCommand(myCommand, myConnection);
            try
            {
                myConnection.Open();
                OleDbDataReader reader = currentCommand.ExecuteReader();

                while (reader.Read())
                {
                    String memberName = reader["FirstName"].ToString();
                    return memberName;
                }
                reader.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                myConnection.Close();
            }


            return null;
        }

        public void newLoan(String dI, String mI, String i, String d)
        {
            OleDbConnection myConnection = new OleDbConnection(connStr);
            String myQuery = "INSERT INTO Loan (DVDID, MemberID, StartDate, ReturnDate) VALUES (@dI, @mI, @i, @d)";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);
            myCommand.Parameters.Add("@dI", OleDbType.VarChar).Value = dI;
            myCommand.Parameters.Add("@mI", OleDbType.VarChar).Value = mI;
            myCommand.Parameters.Add("@i", OleDbType.VarChar).Value = i;
            myCommand.Parameters.Add("@d", OleDbType.VarChar).Value = d;
            Console.WriteLine("Inserting: " + dI + " " + mI + " " + i + " " + d);

            try
            {
                myConnection.Open();
                myCommand.ExecuteNonQuery();
                Console.WriteLine("Inserting: " + dI + " " + mI + " " + i + " " + d);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                myConnection.Close();
            }
            }
        

        public void returnLoan(String lI) { 
           
                OleDbConnection myConnection = new OleDbConnection(connStr);
                String myQuery = "DELETE FROM Loan WHERE [LoanID] =" + lI + "";
                OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);
                try
                {
                    myConnection.Open();
                    myCommand.ExecuteNonQuery();
                    Console.WriteLine("Deleting loan: " + lI);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                finally
                {
                    myConnection.Close();

                }
            }

        public void stockSorter(String i, bool o)
        {
            String myQuery = null;
            OleDbConnection myConnection = new OleDbConnection(connStr);
            
            if (o == true)
            {
                myQuery = "UPDATE DVD SET Stock = Stock - 1 WHERE DVDID=" + i + "";
            }
            if (o == false)
            {

                myQuery = "UPDATE DVD SET Stock = Stock + 1 WHERE DVDID=" + i + "";
            }
            Console.WriteLine(myQuery);
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);
            try
            {
                myConnection.Open();
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                myConnection.Close();
            }
        }
        public String getDVDID(String lI) {
            OleDbConnection myConnection = new OleDbConnection(connStr);
            String myQuery = "SELECT DVDID FROM Loan WHERE LoanID=" + lI + "";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);
            try
            {
                myConnection.Open();
                OleDbDataReader reader = myCommand.ExecuteReader();
                while (reader.Read())
                {
                    String DVDID = reader["DVDID"].ToString();
                    return DVDID;
                }
                reader.Close();


                return null;
            }
            catch (Exception ex) {
                Console.WriteLine(ex.ToString());
            }
            return null;
        }

        public List<DVD> checkDVD(String c) {
            
            String myQuery = "SELECT * FROM DVD WHERE DVDID=" + c + "";
            
            OleDbConnection myConnection = new OleDbConnection(connStr);
            List<DVD> AllDVDs = new List<DVD>();
            OleDbCommand currentCommand = new OleDbCommand(myQuery, myConnection);

            myConnection.Open();
            OleDbDataReader myReader = currentCommand.ExecuteReader();

            while (myReader.Read())
            {
                DVD MyDVD = new DVD();
                MyDVD.DVDID = myReader["DVDID"].ToString();
                MyDVD.DVDTitle = myReader["DVDTitle"].ToString();
                MyDVD.Stock = myReader["Stock"].ToString();
                MyDVD.Director = myReader["Director"].ToString();
                MyDVD.Genre = myReader["Genre"].ToString();
                MyDVD.MainActor = myReader["MainActor"].ToString();
                AllDVDs.Add(MyDVD);
            }
            foreach (DVD item in AllDVDs)
            {
                Console.Write(item.DVDID + " " + item.DVDTitle + "  " + item.Stock + "  " + item.Director + " " + item.Genre + " " + item.MainActor + "\n");
            }
            return AllDVDs;
            
        }

        public List<Loan> checkLoan(String c)
        {
            String myQuery = "SELECT * FROM Loan WHERE MemberID = " + c + "";
           
            List<Loan> AllLoans = new List<Loan>();
            Console.WriteLine(myQuery);
            myConnection = new OleDbConnection(connStr);
            
            OleDbCommand currentCommand = new OleDbCommand(myQuery, myConnection);
         
                myConnection.Open();
                OleDbDataReader myReader = currentCommand.ExecuteReader();

                while (myReader.Read())
                {
                    Loan MyLoan = new Loan();
                    MyLoan.LoanId = myReader["LoanID"].ToString();
                    MyLoan.DVDID = myReader["DVDID"].ToString();
                    MyLoan.MemberID = myReader["MemberID"].ToString();
                    MyLoan.StartDate = myReader["StartDate"].ToString();
                    MyLoan.ReturnDate = myReader["ReturnDate"].ToString();
                    MyLoan.Fine = myReader["Fine"].ToString();
                    String dueStr = myReader["ReturnDate"].ToString();
                    DateTime due = DateTime.Parse(dueStr);
                    int fine;
                    if (DateTime.Now > due)
                    {

                        TimeSpan timespan = DateTime.Now.Subtract(due);
                        Console.WriteLine("There are {0} number of days between {1} and {2}", timespan.TotalDays, DateTime.Now.ToShortDateString(), due.ToShortDateString());
                        if (timespan.TotalDays > 1)
                        {
                            fine = 5;
                            MyLoan.Fine = fine.ToString();
                        } 
                        if (timespan.TotalDays > 5)
                        {
                            fine = 50;
                            MyLoan.Fine = fine.ToString();
                        }
                        if (timespan.TotalDays > 10)
                        {
                            fine = 75;
                            MyLoan.Fine = fine.ToString();
                        }
                        if (timespan.TotalDays > 30)
                        {
                            fine = 200;
                            MyLoan.Fine = fine.ToString();
                        }

                    }
                    else
                    {
                        fine = 0;
                        MyLoan.Fine = fine.ToString();
                    }
                    AllLoans.Add(MyLoan);
                }
                foreach (Loan item in AllLoans)
                {
                    Console.Write(item.LoanId + " " + item.DVDID + "  " + item.MemberID + "  " + item.StartDate + " " + item.ReturnDate + "\n");
                }
            
           
            return AllLoans;
        }

        public void registerMember(string ti, string fn, string ln, string a, string c, string p, string te, string ty) {
            
                OleDbConnection myConnection = new OleDbConnection(connStr);
                String myQuery = "INSERT INTO Member(Title, FirstName, Surname, Address, County, PostCode, Telephone, TypeOfMember) VALUES (@ti, @fn, @ln, @a, @c, @p, @te, @t)";
                OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);


                myCommand.Parameters.Add("@ti", OleDbType.VarChar).Value = ti;
                myCommand.Parameters.Add("@fn", OleDbType.VarChar).Value = fn;
                myCommand.Parameters.Add("@ln", OleDbType.VarChar).Value = ln;
                myCommand.Parameters.Add("@a", OleDbType.VarChar).Value = a;
                myCommand.Parameters.Add("@c", OleDbType.VarChar).Value = c;
                myCommand.Parameters.Add("@p", OleDbType.VarChar).Value = p;
                myCommand.Parameters.Add("@te", OleDbType.VarChar).Value = te;
                myCommand.Parameters.Add("@ty", OleDbType.VarChar).Value = ty;

                try
                {
                    myConnection.Open();
                    myCommand.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Exception in DBHandler", ex);
                }
                finally
                {
                    myConnection.Close();
                }
            
            
        }

        public void updateMember(string mI, string ti, string fn, string ln, string a, string c, string p, string te, string ty) {
            OleDbConnection myConnection = new OleDbConnection(connStr);
            String myQuery = "UPDATE Member SET Title='" + ti +
                             "', FirstName ='" + fn +
                             "', Surname ='" + ln +
                             "', Address ='" + a +
                             "', County ='" + c +
                             "', PostCode ='" + p +
                             "', Telephone ='" + te +
                             "', TypeOfMember ='" + ty +

                             "' WHERE MembershipID=" + mI + "";
            OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);
            Console.WriteLine(myQuery);
            try
            {
                myConnection.Open();
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                myConnection.Close();
            }
        }

        public void deleteMember(string mI) {
            
                OleDbConnection myConnection = new OleDbConnection(connStr);
                String myQuery = "DELETE FROM Member WHERE [MembershipID] =" + mI + "";
                OleDbCommand myCommand = new OleDbCommand(myQuery, myConnection);
            Console.WriteLine(myQuery);
                try
                {
                    myConnection.Open();
                    myCommand.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                finally
                {
                    myConnection.Close();

                }
            }
        }
}
