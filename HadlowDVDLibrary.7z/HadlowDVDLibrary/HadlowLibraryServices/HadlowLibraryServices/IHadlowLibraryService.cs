﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.Data.OleDb;

namespace HadlowLibraryServices
{
    [ServiceContract]
    interface IHadlowLibraryService
    {
        [OperationContract]
        List<DVD> getAllDVDs();
        [OperationContract]
        List<DVD> getDVDIds(bool i);
        [OperationContract]
        List<DVD> getInStockDVDs();
        [OperationContract]
        List<Loan> getAllLoans();
        [OperationContract]
        List<Loan> getLoanIds();
        [OperationContract]
        String getDVDID(String lI);
        [OperationContract]
        List<Member> getAllMembers();
        [OperationContract]
        List<Member> getMemberIds();
        [OperationContract]
        String getFilmTitle(String i);
        [OperationContract]
        String getMemberName(String i);
        [OperationContract]
        void newLoan(String dI, String mI, String i, String d);
        [OperationContract]
        void returnLoan(String lI);
        [OperationContract]
        void stockSorter(String i, bool o);
        [OperationContract]
        List<Loan> checkLoan(String c);
        [OperationContract]
        List<DVD> checkDVD(String c);
        [OperationContract]
        void registerMember(string ti, string fn, string ln, string a, string c, string p, string te, string ty);
        [OperationContract]
        void updateMember(string mI, string ti, string fn, string ln, string a, string c, string p, string te, string ty);
        [OperationContract]
        void deleteMember(string mI);
    }

    [DataContract]
    public class DVD
    {
        private String _id;
        private String _dvdTitle;
        private String _stock;
        private String _director;
        private String _genre;
        private String _mainActor;

        [DataMember]
        public String DVDID
        {
            get { return _id; }
            set { _id = value; }
        }
        [DataMember]
        public String DVDTitle
        {
            get { return _dvdTitle; }
            set { _dvdTitle = value; }
        }
        [DataMember]
        public String Stock
        {
            get { return _stock; }
            set { _stock = value; }
        }
        [DataMember]
        public String Director
        {
            get { return _director; }
            set { _director = value; }
        }
        [DataMember]
        public String Genre
        {
            get { return _genre; }
            set { _genre = value; }
        }
        [DataMember]
        public String MainActor
        {
            get { return _mainActor; }
            set { _mainActor = value; }
        }
    }

    [DataContract]
    public class Loan
    {
        private String _loanId;
        private String _dvdId;
        private String _memberId;
        private String _startDate;
        private String _returnDate;
        private String _fine;

        [DataMember]
        public String LoanId
        {
            get { return _loanId; }
            set { _loanId = value; }
        }
        [DataMember]
        public String DVDID
        {
            get { return _dvdId; }
            set { _dvdId = value; }
        }
        [DataMember]
        public String MemberID
        {
            get { return _memberId; }
            set { _memberId = value; }
        }
        [DataMember]
        public String StartDate
        {
            get { return _startDate; }
            set { _startDate = value; }
        }
        [DataMember]
        public String ReturnDate
        {
            get { return _returnDate; }
            set { _returnDate = value; }
        }
        [DataMember]
        public String Fine {
            get{ return _fine; }
            set {_fine = value; }
    }
        }
    }
    [DataContract]
    public class Member
    {
        private String _memberId;
        private String _title;
        private String _firstName;
        private String _surName;
        private String _address;
        private String _county;
        private String _postCode;
        private String _telePhone;
        private String _typeOfMember;

        [DataMember]
        public String MemberId
        {
            get { return _memberId; }
            set { _memberId = value; }
        }
        [DataMember]
        public String Title
        {
            get { return _title; }
            set { _title = value; }
        }
        [DataMember]
        public String FirstName
        {
            get { return _firstName; }
            set { _firstName = value; }
        }
        [DataMember]
        public String SurName
        {
            get { return _surName; }
            set { _surName = value; }
        }
        [DataMember]
        public String Address
        {
            get { return _address; }
            set { _address = value; }
        }
        [DataMember]
        public String County
        {
            get { return _county; }
            set { _county = value; }
        }
        [DataMember]
        public String PostCode
        {
            get { return _postCode; }
            set { _postCode = value; }
        }
        [DataMember]
        public String TelePhone
        {
            get { return _telePhone; }
            set { _telePhone = value; }
        }
        [DataMember]
        public String TypeOfMember
        {
            get { return _typeOfMember; }
            set { _typeOfMember = value; }
        }
    }


